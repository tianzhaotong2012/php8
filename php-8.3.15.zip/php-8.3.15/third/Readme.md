## download lib ##
- wget "https://ftp.gnu.org/pub/gnu/libiconv/libiconv-1.14.tar.gz"
- libiconv-1.14.tar.gz  md5:e34509b1623cec449dfeb73d7ce9c6c6
- wget "https://www.openssl.org/source/openssl-1.0.1s.tar.gz"
- 562986f6937aabc7c11a6d376d8a0d26  openssl-1.0.1s.tar.gz
- wget "http://www.zlib.net/zlib-1.2.11.tar.gz"
- 1c9f62f0778697a09d36121ead88e08e  zlib-1.2.11.tar.gz
- 3adb0e35d3c100c456357345ccfa8056  freetype-2.9.1.tar.gz
- wget "https://curl.haxx.se/download/curl-7.21.7.tar.gz"
- 3bbdab8bf540d73d10d2a82d964bc20a  curl-7.21.7.tar.gz 

    
