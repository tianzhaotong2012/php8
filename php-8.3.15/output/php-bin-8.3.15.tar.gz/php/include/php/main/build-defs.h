/*
   +----------------------------------------------------------------------+
   | Copyright (c) The PHP Group                                          |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | https://www.php.net/license/3_01.txt                                 |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig Sæther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

#define CONFIGURE_COMMAND " './configure'  '--prefix=/home/work/php8-master/php-8.3.15/.tmp/install/php' '--with-config-file-path=/home/work/php8-master/php-8.3.15/.tmp/install/php/etc' '--with-config-file-scan-dir=/home/work/php8-master/php-8.3.15/.tmp/install/php/etc/ext' '--with-openssl=/home/work/php8-master/php-8.3.15/.tmp/build/../third/openssl' '--with-curl' '--enable-gd' '--enable-mysqlnd' '--with-mysqli' '--with-pdo-mysql' '--without-sqlite3' '--without-pdo-sqlite' '--with-png' '--with-jpeg' '--disable-mbregex' '--enable-opcache' '--enable-bcmath' '--enable-fpm' '--enable-mbstring' '--enable-shmop' '--enable-soap' '--enable-sockets' '--enable-sysvsem' '--enable-pcntl' '--with-iconv' '--with-zip' '--with-zlib' '--with-libxml' '--with-freetype-dir=/usr' '--with-pear=/home/work/php8-master/php-8.3.15/.tmp/install/php' 'PKG_CONFIG_PATH=/home/work/php8-master/php-8.3.15/.tmp/build/../third/lib64/pkgconfig:/home/work/php8-master/php-8.3.15/.tmp/build/../third/openssl/lib64/pkgconfig:/home/work/php8-master/php-8.3.15/.tmp/build/../third/zlib-1.2.11/lib/pkgconfig:/home/work/php8-master/php-8.3.15/.tmp/build/../third/curl/lib/pkgconfig:/home/work/php8-master/php-8.3.15/.tmp/build/../third/libzip/lib/pkgconfig'"
#define PHP_ODBC_CFLAGS	""
#define PHP_ODBC_LFLAGS		""
#define PHP_ODBC_LIBS		""
#define PHP_ODBC_TYPE		""
#define PHP_OCI8_DIR			""
#define PHP_OCI8_ORACLE_VERSION		""
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PEAR_INSTALLDIR         "/home/work/php8-master/php-8.3.15/.tmp/install/php"
#define PHP_INCLUDE_PATH	".:/home/work/php8-master/php-8.3.15/.tmp/install/php"
#define PHP_EXTENSION_DIR       "/home/work/php8-master/php-8.3.15/.tmp/install/php/ext"
#define PHP_PREFIX              "/home/work/php8-master/php-8.3.15/.tmp/install/php"
#define PHP_BINDIR              "/home/work/php8-master/php-8.3.15/.tmp/install/php/bin"
#define PHP_SBINDIR             "/home/work/php8-master/php-8.3.15/.tmp/install/php/sbin"
#define PHP_MANDIR              "/home/work/php8-master/php-8.3.15/.tmp/install/php/php/man"
#define PHP_LIBDIR              "/home/work/php8-master/php-8.3.15/.tmp/install/php/lib/php"
#define PHP_DATADIR             "/home/work/php8-master/php-8.3.15/.tmp/install/php/share/php"
#define PHP_SYSCONFDIR          "/home/work/php8-master/php-8.3.15/.tmp/install/php/etc"
#define PHP_LOCALSTATEDIR       "/home/work/php8-master/php-8.3.15/.tmp/install/php/var"
#define PHP_CONFIG_FILE_PATH    "/home/work/php8-master/php-8.3.15/.tmp/install/php/etc"
#define PHP_CONFIG_FILE_SCAN_DIR    "/home/work/php8-master/php-8.3.15/.tmp/install/php/etc/ext"
#define PHP_SHLIB_SUFFIX        "so"
#define PHP_SHLIB_EXT_PREFIX    ""
